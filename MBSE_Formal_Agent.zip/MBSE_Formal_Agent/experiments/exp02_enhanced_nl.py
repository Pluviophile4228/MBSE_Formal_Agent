import sys
import os
import csv
from operator import itemgetter

# 环境配置
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from langchain_core.prompts import ChatPromptTemplate
from src.llm_interface import get_llm
from src.rag_engine import get_retriever
from src.sanitizer import sanitize_code

INPUT_FILE = os.path.join(project_root, "data", "fha_dataset.csv")
OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp02_enhanced.sysml")

template = """
你是一个 SysML v2 建模助手。请利用参考资料中的**语法知识**，将输入的 FHA 数据转换为 SysML 代码。

1. 参考语法 (Context from RAG)
{context}

2. 输入数据 (FHA Table)
{csv_content}

3. 任务要求
- 为表格中的每个功能组件（如 FCC, EMA）定义 `part def`。
- 尝试根据 DAL 等级（A/B/C）设计冗余结构（如主备、三余度）。
- 仅输出 SysML v2 代码。
"""


def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)


def run_exp02_return_code(verbose=False):
    if verbose:
        print(f" [Exp02] 启动 RAG 增强组实验 (Knowledge-Augmented)...")

    if not os.path.exists(INPUT_FILE):
        print(f"错误: 未找到数据文件 {INPUT_FILE}")
        return ""

    with open(INPUT_FILE, "r", encoding="utf-8-sig") as f:
        csv_content = f.read()

    retriever = get_retriever()
    if not retriever:
        print(" [Exp02] RAG 初始化失败 (VectorStore not found).")
        return ""

    llm = get_llm(temperature=0.1)
    prompt = ChatPromptTemplate.from_template(template)

    retrieval_query = "SysML v2 syntax for component definition, connection, and redundancy patterns"

    retrieved_docs = retriever.invoke(retrieval_query)
    formatted_context = format_docs(retrieved_docs)

    chain = prompt | llm

    try:
        result = chain.invoke({
            "context": formatted_context,
            "csv_content": csv_content
        })

        final_code = sanitize_code(result.content)

    except Exception as e:
        if verbose: print(f" [Exp02] 生成异常: {e}")
        return ""

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(final_code)

    if verbose:
        print(f" [Exp02] 完成。输出已保存: {OUTPUT_FILE}")

    return final_code


if __name__ == "__main__":
    run_exp02_return_code(verbose=False)