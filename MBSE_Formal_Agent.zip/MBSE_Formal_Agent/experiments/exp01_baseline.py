import sys
import os
import csv
from langchain_core.prompts import ChatPromptTemplate
from src.llm_interface import get_llm
from src.sanitizer import sanitize_code

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

INPUT_FILE = os.path.join(project_root, "data", "fha_dataset.csv")
OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp01_baseline.sysml")

template = """
你是一个系统架构师。请根据以下 FHA（功能危害性分析）表格数据，直接生成对应的 SysML v2 系统架构代码。

输入数据 (CSV格式)
{csv_content}

要求
1. 识别出关键组件（如 FCC, EMA, AI 等）。
2. 尝试根据 DAL 等级（A/B/C）设计冗余结构（如主备、三余度）。
3. 仅输出 SysML v2 代码。
"""


def run_exp01_return_code(verbose=False):
    if verbose:
        print(" [Exp01] 启动基线实验 (Naive LLM)...")

    if not os.path.exists(INPUT_FILE):
        print(f"错误: 未找到数据文件 {INPUT_FILE}")
        return ""

    with open(INPUT_FILE, "r", encoding="utf-8-sig") as f:
        csv_content = f.read()

    llm = get_llm(temperature=0.1)
    prompt = ChatPromptTemplate.from_template(template)

    chain = prompt | llm

    try:
        result = chain.invoke({"csv_content": csv_content})
        raw_code = result.content

        final_code = sanitize_code(raw_code)

    except Exception as e:
        if verbose: print(f" [Exp01] 生成失败: {e}")
        return ""

    # 4. 保存
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(final_code)

    if verbose:
        print(f" [Exp01] 完成。输出已保存: {OUTPUT_FILE}")

    return final_code


if __name__ == "__main__":
    run_exp01_return_code(verbose=False)