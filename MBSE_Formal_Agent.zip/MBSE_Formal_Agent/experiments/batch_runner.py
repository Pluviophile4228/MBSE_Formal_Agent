import sys
import os
import time
import pandas as pd
import traceback
import matplotlib.pyplot as plt


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from src.evaluator import Evaluator
from experiments.exp01_baseline import run_exp01_return_code
from experiments.exp02_enhanced_nl import run_exp02_return_code
from experiments.exp03_formal_guided import run_exp03_return_code
from experiments.exp04_integrated_system import run_exp04_return_code


def safe_run_experiment(run_func, exp_name):

    try:
        t0 = time.time()
        code = run_func(verbose=False)
        duration = time.time() - t0

        metrics = Evaluator.evaluate(code)

        metrics['Time(s)'] = duration
        return metrics, code

    except Exception as e:
        print(f"  [Error] {exp_name} 崩溃: {str(e)}")
        return {
            "syntax": 0.0,
            "topology": 0.0,
            "no_hallucination": 0.0,
            "Time(s)": 0.0
        }, ""


def run_batch_test(rounds=100):
    all_results = []
    print(f" 启动批量对比测试 (N={rounds})...")

    total_start_time = time.time()

    for i in range(rounds):
        print(f"--- Round {i + 1}/{rounds} ---")

        m1, _ = safe_run_experiment(run_exp01_return_code, "G1")
        m1['Group'] = 'G1 (Baseline)'
        m1['Round'] = i + 1
        all_results.append(m1)

        m2, _ = safe_run_experiment(run_exp02_return_code, "G2")
        m2['Group'] = 'G2 (RAG)'
        m2['Round'] = i + 1
        all_results.append(m2)

        m3, _ = safe_run_experiment(run_exp03_return_code, "G3")
        m3['Group'] = 'G3 (Guided-CoT)'
        m3['Round'] = i + 1
        all_results.append(m3)

        m4, _ = safe_run_experiment(run_exp04_return_code, "G4")
        m4['Group'] = 'G4 (Ours)'
        m4['Round'] = i + 1
        all_results.append(m4)

        print(f"  > G4 Score: Syn={m4['syntax']}, Topo={m4['topology']}")

    total_duration = time.time() - total_start_time
    df = pd.DataFrame(all_results)

    raw_csv_path = os.path.join(project_root, "results", "metrics_raw_N100.csv")
    os.makedirs(os.path.dirname(raw_csv_path), exist_ok=True)
    df.to_csv(raw_csv_path, index=False)

    summary = df.groupby("Group").agg(['mean', 'std'])
    summary_csv_path = os.path.join(project_root, "results", "metrics_summary_N100.csv")
    summary.to_csv(summary_csv_path)

    print("\n" + "=" * 40)
    print(f" 总耗时: {total_duration / 60:.2f} 分钟")

    return summary



if __name__ == "__main__":
    run_batch_test(rounds=100)