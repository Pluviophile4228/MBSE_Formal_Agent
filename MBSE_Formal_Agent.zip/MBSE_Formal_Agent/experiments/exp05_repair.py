import sys
import os
import re
from langchain_core.prompts import ChatPromptTemplate
from src.llm_interface import get_llm
from src.sanitizer import sanitize_code


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

BAD_OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp05_case_a_hallucination.sysml")
FIXED_OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp05_case_b_fixed.sysml")

def mock_ocl_validator(code):

    errors = []
    code_lower = code.lower()

    if "fcc" in code_lower and "voter" not in code_lower:
        errors.append("-> [OCL Error]: Violation of Pattern <TMR>. Component 'Voter' is missing in 'FCC'.")


    lines = code.split('\n')
    for line in lines:
        clean_line = line.lower().strip()
        if "connect" in clean_line and "lane" in clean_line:
            if "voter" not in clean_line and (
                    "ema" in clean_line or "output" in clean_line or "actuator" in clean_line):
                errors.append(
                    f"-> [OCL Error]: Safety Violation (Bypass). Redundant lane connects directly to sink without Voting: '{line.strip()}'")

    if not errors:
        return True, "PASSED"
    else:
        return False, "\n".join(errors)

template_stage1 = """
你是一个且急于求成的程序员。请快速写一个 SysML v2 的 FCC (Flight Control Computer) 架构。

需求：
1. 包含 3 个冗余通道 (lane1, lane2, lane3)。
2. 包含一个外部执行器 (EMA)。
3. 关键指令：为了简化连线，请直接将这 3 个 lane 连接到 EMA。不要搞复杂的中间件。
4. 必须符合 SysML v2 语法 (使用 package, part def, connect)。

输出：
仅输出 SysML v2 代码。
"""

template_repair = """
你是一个资深适航架构师。上一轮生成的代码违反了安全硬约束。
请利用你的推理能力，根据错误日志重构代码。

1. 错误日志 (OCL Feedback)
{error_log}

2. 适航设计规则 (ACKG Constraints)
- Rule 3.2 (Independence): DAL A 级系统 (FCC) 严禁通道直连输出。
- Rule 3.3 (Voting): 三模冗余 (TMR) 模式必须包含一个 `Voter` 组件。所有 `Lane` 必须先连接到 `Voter`，再由 `Voter` 连接到外部。

3. 修复任务
请修正代码中的拓扑错误。
- 保持 package 和 part def 的语法结构。
- 插入 缺失的 Voter 组件。
- 重路由 连接：断开 lane->ema 的直连，建立 lane->voter->ema 的链路。

输出：
仅输出修复后的 SysML v2 代码。
"""


def run_exp05():
    print("==========================================")
    print(" Exp05: Robustness & Self-Healing (N <= 3)")
    print("==========================================")

    llm = get_llm(temperature=0.1)

    print("\n[Phase 1] Injecting Topological Hallucination...")
    chain1 = ChatPromptTemplate.from_template(template_stage1) | llm
    res1 = chain1.invoke({})
    current_code = sanitize_code(res1.content)

    print(f"-> Generated 'Toxic' Code (Snippet):\n{current_code[:300]}...\n")
    with open(BAD_OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(current_code)

    MAX_RETRIES = 3
    repair_chain = ChatPromptTemplate.from_template(template_repair) | llm

    converged = False

    for i in range(MAX_RETRIES):
        print(f"\n--- Round {i + 1} Verification ---")
        is_valid, error_msg = mock_ocl_validator(current_code)

        if is_valid:
            print(f" [Success] Architecture converged to VALID state in Round {i + 1}!")
            converged = True
            break

        print(f" [Violation Detected] OCL Validator triggered:\n{error_msg}")
        print(" -> Activating Neuro-Symbolic Repair Agent...")


        res = repair_chain.invoke({"error_log": error_msg})
        current_code = sanitize_code(res.content)

    if converged:
        with open(FIXED_OUTPUT_FILE, "w", encoding="utf-8") as f:
            f.write(current_code)
        print(f"\n[Result] Fixed code saved to {FIXED_OUTPUT_FILE}")
    else:
        print("\n[Failure] Model failed to converge.")


if __name__ == "__main__":
    run_exp05()