import sys
import os
import csv
import json
from langchain_core.prompts import ChatPromptTemplate
from src.llm_interface import get_llm
from src.sanitizer import sanitize_code

from src.rag_engine import get_retriever


current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

INPUT_FILE = os.path.join(project_root, "data", "fha_dataset.csv")
PATTERN_FILE = os.path.join(project_root, "data", "pattern_library.json")
OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp03_formal.sysml")


template = """
你是一个资深的系统安全架构师。请参考提供的**SysML v2 语法知识**，并严格按照**思维链 (Chain of Thought)** 步骤，将输入的 FHA 表格转换为 SysML v2 架构模型。

1. 参考语法 (Syntax Knowledge)
{context}

2. 输入：可用安全模式库 (Pattern Library)
{pattern_context}

3. 输入：FHA 数据表
{csv_content}

4. 推理步骤 (CoT)
1. 语义归约 (Grouping): 分析 FHA 表格，将涉及相同物理组件的行合并（例如将所有涉及 "Pitch", "Roll", "FCC" 的行归为 "FCC" 组件）。
2. 等级评估 (DAL Assessment): 对于每个组件，取其所有失效状态中的**最高严重等级**（A > B > C > D）。
3. 模式匹配 (Pattern Selection): 
    - DAL A (Catastrophic) -> 必须选择高冗余模式 (如 M-out-of-N Voting)。
    - DAL B (Hazardous) -> 选择冗余模式 (如 Standby 或 Cross Comparison)。
    - DAL C/D -> 选择单通道或监控模式。
4. 代码生成: 基于参考语法生成 SysML v2 代码，定义 `package FlightControlSystem`，并在其中实例化这些组件。

输出要求
- 仅输出 SysML v2 代码。
- 严禁使用 PlantUML 或其他 UML 变体。
- 确保包含 `part def` 和 `connect`。
"""

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

def load_patterns_text():
    if not os.path.exists(PATTERN_FILE):
        return "No patterns available."
    with open(PATTERN_FILE, "r", encoding="utf-8") as f:
        patterns = json.load(f)
    pattern_text = ""
    for p in patterns:
        pattern_text += f"- Pattern: {p['name']} (ID: {p['id']})\n"
        pattern_text += f"  Description: {p['description']}\n"
        pattern_text += f"  Typical DAL: {'A/B' if 'Redundancy' in p['name'] or 'Voting' in p['name'] else 'C/D'}\n\n"
    return pattern_text


def run_exp03_return_code(verbose=False):
    if verbose:
        print(" [Exp03] 启动形式化引导组实验 (CoT + Syntax RAG)...")

    if not os.path.exists(INPUT_FILE):
        print(f"错误: 未找到数据文件 {INPUT_FILE}")
        return ""
    with open(INPUT_FILE, "r", encoding="utf-8-sig") as f:
        csv_content = f.read()

    pattern_context = load_patterns_text()

    retriever = get_retriever()
    if not retriever:
        print(" [Exp03] 警告: RAG 初始化失败，将退化为纯 CoT。")
        context = "No syntax guide available."
    else:
        retrieval_query = "SysML v2 syntax for component definition, connection, and redundancy patterns"
        retrieved_docs = retriever.invoke(retrieval_query)
        context = format_docs(retrieved_docs)

    llm = get_llm(temperature=0.1)
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm

    try:
        result = chain.invoke({
            "csv_content": csv_content,
            "pattern_context": pattern_context,
            "context": context
        })
        final_code = sanitize_code(result.content)

    except Exception as e:
        if verbose: print(f" [Exp03] 生成失败: {e}")
        return ""

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(final_code)

    if verbose:
        print(f" [Exp03] 完成。输出已保存: {OUTPUT_FILE}")
        if "RTA" not in final_code and "Voting" in final_code:
            print("  [关键观察] G3 语法已修正，但逻辑依然未能识别 AI 专用架构 (RTA)。")

    return final_code


if __name__ == "__main__":
    run_exp03_return_code(verbose=False)