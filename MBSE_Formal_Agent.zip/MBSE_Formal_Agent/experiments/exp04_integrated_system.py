import sys
import os
import csv
import json
from operator import itemgetter

# 环境配置
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from langchain_core.prompts import ChatPromptTemplate
from src.llm_interface import get_llm
from src.pattern_matcher import PatternMatcher
from src.sanitizer import sanitize_code

# ================= 配置 =================
FHA_FILE = os.path.join(project_root, "data", "fha_dataset.csv")
PATTERN_FILE = os.path.join(project_root, "data", "pattern_library.json")
OUTPUT_FILE = os.path.join(project_root, "results", "raw_code", "exp04_integrated_system.sysml")


# ================= 领域专家规则 (Domain Rules) =================
def apply_domain_rules(comp_name, original_pattern_id, dal, pattern_lib):
    if "AI" in comp_name or "Autonomous" in comp_name:
        return "RTA"
    if "EMA" in comp_name or "Actuator" in comp_name:
        if dal in ["A", "B"]: return "SR"
    if "Sensor" in comp_name and dal == "A":
        return "CC"  # 传感器强制用交叉比对 (Cross Comparison)
    if "IFE" in comp_name:
        return "PSC"
    return original_pattern_id


# ================= 系统级 Prompt =================
template = """
你是一个 SysML v2 系统架构师。请根据【系统蓝图】生成一个完整的飞行控制系统架构。

0. 范例教学
蓝图: 
- 组件 FCC (DAL A): 使用 TMR 模式
- 组件 AI_Pilot (DAL A): 使用 RTA 模式
输出:
package System {{
    part def FCC {{ attribute dal : String = "A"; attribute pattern : String = "TMR"; 
                    part lane1; ... part voter; connect... }}
    part def AI_Pilot {{ part ai_core; part safety_monitor; part switch; connect... }}
    part fcc : FCC;
    part ai : AI_Pilot;
    
    connect ai.output to fcc.input;
}}

 1. 系统蓝图 (System Blueprint)
请为以下每一个组件定义 `part def`，并严格应用指定的安全模式：

{blueprint_str}

2. 系统集成 (System Integration)
在定义完上述所有子系统后，请在 `part def FlightControlSystem` 中将它们实例化并连接起来：
   - 实例化所有组件: fcc, ema, ai_pilot, sensor_unit, ife, cabin_pressure.
   - 连接: SensorUnit -> FCC -> EMA.
   - 连接: AI_Pilot -> FCC.
   - 连接: IFE, CabinPressure -> MainBus.

3. 参考语法
{context}

绝对禁止
1. 严禁使用 UML (`class`, `operation`)。
2. 严禁使用箭头 `->`。
3. 必须显式定义所有蓝图中提到的组件，不要遗漏。
4. 尽可能包含属性attribute
输出
仅输出 SysML v2 代码。
"""


def run_exp04_return_code(verbose=False):
    if verbose: print(" [Exp04-Pro] 启动系统级综合实验...")

    matcher = PatternMatcher(PATTERN_FILE)

    with open(PATTERN_FILE, 'r', encoding='utf-8') as f:
        pattern_lib_list = json.load(f)
        pattern_lib_dict = {p['id']: p for p in pattern_lib_list}

    llm = get_llm(temperature=0.1)
    prompt = ChatPromptTemplate.from_template(template)


    with open(FHA_FILE, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fha_data = list(reader)

    if verbose: print(f" 正在分析 {len(fha_data)} 条失效状态 (执行智能归约)...")

    DAL_PRIORITY = {"A": 4, "B": 3, "C": 2, "D": 1, "E": 0}
    consolidated_specs = {}


    for row in fha_data:

        full_text = (str(row.get('Top Function', '')) + " " +
                     str(row.get('Sub-Function', '')) + " " +
                     str(row.get('Detailed Failure Condition', '')).lower())

        comp_name = "General_Avionics"


        if any(kw in full_text for kw in ["flight control", "fcc", "pitch", "roll", "yaw", "computer", "thrust"]):
            comp_name = "FCC"

        elif any(kw in full_text for kw in ["actuation", "ema", "motor", "aileron", "elevator", "surface", "actuator"]):
            comp_name = "EMA"

        elif any(kw in full_text for kw in
                 ["autonomous", "ai agent", "neural", "rta", "intelligent", "algorithm", "perception"]):
            comp_name = "AI_Pilot"

        elif any(kw in full_text for kw in
                 ["sensor", "air data", "imu", "navigation", "airspeed", "altitude", "attitude", "inertial"]):
            comp_name = "SensorUnit"

        elif any(kw in full_text for kw in ["cabin", "pressure"]):
            comp_name = "CabinPressure"

        elif any(kw in full_text for kw in ["infotainment", "ife", "video", "audio", "entertainment", "broadcast"]):
            comp_name = "IFE"

        current_dal = row.get('DAL', 'E').strip().upper()
        current_score = DAL_PRIORITY.get(current_dal, 0)

        if comp_name not in consolidated_specs:
            consolidated_specs[comp_name] = {"max_score": current_score, "best_row": row}
        else:
            if current_score > consolidated_specs[comp_name]["max_score"]:
                consolidated_specs[comp_name]["max_score"] = current_score
                consolidated_specs[comp_name]["best_row"] = row

    if "General_Avionics" in consolidated_specs:
        if verbose:
            print(" [Warning] 仍有部分组件落入 General_Avionics，请检查关键词覆盖。")

    # 4. 构建蓝图
    blueprint_parts = []
    for comp_name, spec in consolidated_specs.items():
        if comp_name == "General_Avionics": continue

        row = spec['best_row']
        dal = row['DAL']

        match_result = matcher.analyze_and_match(row)
        initial_pattern_id = match_result['pattern_id']
        final_pattern_id = apply_domain_rules(comp_name, initial_pattern_id, dal, pattern_lib_dict)

        pattern = pattern_lib_dict.get(final_pattern_id)

        if verbose:
            print(f"  -> [{comp_name}] DAL {dal} | 模式: {final_pattern_id}")

        hints = [f"{v.strip()};" for k, v in pattern.get("mapping_hints", {}).items()]
        mapping_str = " ".join(hints)
        topology_def = pattern.get("formal_definition", {}).get("topology_G", "")
        e_set = topology_def.split("E=")[-1].replace("{", "").replace("}", "") if "E=" in topology_def else ""

        part_desc = f"""
        --- Component: {comp_name} ---
        [Requirement]: DAL {dal}
        [Applied Pattern]: {pattern['name']}
        [Internal Parts]: {mapping_str}
        [Topology Rules]: {e_set}
        ---------------------------
        """
        blueprint_parts.append(part_desc)

    full_blueprint = "\n".join(blueprint_parts)

    # 5. 生成代码
    chain = (
            {
                "context": lambda x: "SysML v2 syntax...",
                "blueprint_str": lambda x: full_blueprint
            }
            | prompt
            | llm
    )

    result = chain.invoke({})
    final_code = sanitize_code(result.content)

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(final_code)

    if verbose:
        print(f"\n [Success] 系统级架构已生成: {OUTPUT_FILE}")

    return final_code


if __name__ == "__main__":
    run_exp04_return_code(verbose=False)