import re
def sanitize_code(raw_code):
    lines = raw_code.split('\n')
    fixed_lines = []


    for line in lines:
        stripped = line.strip()
        if stripped.startswith("```"): continue
        if "«" in line or "»" in line:
            line = line.replace("«", "").replace("»", "")

        if "->" in line and "connect" in line:
            line = line.replace("->", "to")

        if stripped.startswith("class ") or stripped.startswith("operation "):

            continue

        fixed_lines.append(line)

    return "\n".join(fixed_lines)