import re


class Evaluator:
    @staticmethod
    def evaluate(sysml_code):

        metrics = {
            "syntax": 0.0,
            "topology": 0.0,
            "no_hallucination": 0.0
        }

        if not sysml_code or len(sysml_code) < 10:
            return metrics

        has_package = "package " in sysml_code
        has_part = "part def " in sysml_code
        has_connect = "connect " in sysml_code

        open_braces = sysml_code.count("{")
        close_braces = sysml_code.count("}")
        braces_match = (open_braces == close_braces) and (open_braces > 0)

        score_syn = 0.0
        if has_package: score_syn += 0.2
        if has_part: score_syn += 0.4
        if has_connect: score_syn += 0.2
        if braces_match: score_syn += 0.2

        metrics["syntax"] = round(score_syn, 2)

        if metrics["syntax"] < 0.4:
            return metrics

        topo_scores = []
        code_lower = sysml_code.lower()

        if "part def fcc" in code_lower or "part def flightcontrol" in code_lower:
            has_voter = any(k in code_lower for k in ["voter", "voting"])

            lane_count = code_lower.count("lane") + code_lower.count("proc")
            has_lanes = lane_count >= 2

            if has_voter and has_lanes:
                topo_scores.append(1.0)
            elif has_voter:
                topo_scores.append(0.5)
            else:
                topo_scores.append(0.0)

        if "part def ai_pilot" in code_lower or "part def autonomous" in code_lower:
            has_monitor = any(k in code_lower for k in ["monitor", "safety"])
            has_switch = "switch" in code_lower

            if has_monitor and has_switch:
                topo_scores.append(1.0)
            elif has_monitor or has_switch:
                topo_scores.append(0.5)
            else:
                topo_scores.append(0.0)

        if "part def ema" in code_lower or "part def actuator" in code_lower:
            has_switch = "switch" in code_lower
            if has_switch:
                topo_scores.append(1.0)
            else:
                topo_scores.append(0.0)

        if topo_scores:
            metrics["topology"] = sum(topo_scores) / len(topo_scores)
        else:
            metrics["topology"] = 0.0

        hallucination_penalty = 0.0

        if "connect lane" in code_lower and "voter" in code_lower:

            bypass_pattern = r"connect\s+lane\w+\s+to\s+(?!voter)"
            if re.search(bypass_pattern, code_lower):
                hallucination_penalty += 0.5  # 扣大分

        if "part def ai_pilot" in code_lower and "monitor" in code_lower:
            # 如果 AI Core 直接连到了 output，跳过了 switch
            if "connect ai_core to output" in code_lower:
                hallucination_penalty += 0.5

        if "cloud" in code_lower or "internet" in code_lower or "wifi" in code_lower:
            hallucination_penalty += 0.2

        metrics["no_hallucination"] = max(0.0, 1.0 - hallucination_penalty)

        return metrics