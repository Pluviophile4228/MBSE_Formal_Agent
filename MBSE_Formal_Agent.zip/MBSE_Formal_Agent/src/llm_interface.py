from langchain_ollama import ChatOllama

def get_llm(temperature=0.1):
    return ChatOllama(
        base_url="http://localhost:11434",
        model="qwen2.5-coder:7b",
        temperature=temperature
    )