import csv
import os
import json


class PatternMatcher:
    def __init__(self, library_path):
        self.library_path = library_path
        self.patterns = self._load_library()

    def _load_library(self):
        if not os.path.exists(self.library_path):
            return []
        with open(self.library_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def analyze_and_match(self, fha_row):

        dal = fha_row.get('DAL', 'D').strip().upper()
        desc = fha_row.get('功能描述', '')

        reasoning = []
        reasoning.append(f"分析组件: {fha_row.get('ID')} (DAL {dal})")

        selected_pattern_id = None


        if "智能" in desc or "算法" in desc or "AI" in desc:
            if dal in ['A', 'B']:
                reasoning.append("检测到高等级 AI/算法功能 -> 触发公理 3.3 (设计共模错误) -> 推荐 RTA 模式")
                selected_pattern_id = "RTA"


        if not selected_pattern_id:
            if dal == 'A':

                reasoning.append("检测到 DAL A 级关键功能 -> 触发公理 3.2 (高可用性) -> 推荐 MN/TMR 模式")
                selected_pattern_id = "MN"
            elif dal == 'B':

                reasoning.append("检测到 DAL B 级重要功能 -> 触发公理 3.1 (完整性/可用性平衡) -> 推荐 SR 模式")
                selected_pattern_id = "SR"
            elif dal == 'C':
                reasoning.append("检测到 DAL C 级功能 -> 推荐轻量级监控 -> 推荐 PSC 模式")
                selected_pattern_id = "PSC"
            else:

                reasoning.append("检测到 DAL D 级非关键功能 -> 无需额外模式 -> 推荐 Simplex")
                selected_pattern_id = "Simplex"

        pattern_detail = next((p for p in self.patterns if p['id'] == selected_pattern_id), None)

        return {
            "pattern_id": selected_pattern_id,
            "pattern_name": pattern_detail['name'] if pattern_detail else "Basic Architecture",
            "reasoning": " > ".join(reasoning),
            "detail": pattern_detail
        }