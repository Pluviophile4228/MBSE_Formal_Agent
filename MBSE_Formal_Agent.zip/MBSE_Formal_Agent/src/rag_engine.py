
import os
import shutil
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PDF_FOLDER = os.path.join(BASE_DIR, "data", "pdfs")
DB_DIR = os.path.join(BASE_DIR, "data", "vector_db")


def get_retriever(rebuild=False):
    embeddings = OllamaEmbeddings(model="nomic-embed-text", base_url="http://localhost:11434")


    if rebuild or not (os.path.exists(DB_DIR) and os.listdir(DB_DIR)):
        print(f" [RAG] 正在从 {PDF_FOLDER} 构建向量库...")
        if os.path.exists(DB_DIR):
            shutil.rmtree(DB_DIR)

        docs = []

        if not os.path.exists(PDF_FOLDER):
            os.makedirs(PDF_FOLDER)
            print(f" 警告: 请确保 PDF 文件已放入 {PDF_FOLDER}")
            return None

        for filename in os.listdir(PDF_FOLDER):
            if filename.endswith(".pdf"):
                path = os.path.join(PDF_FOLDER, filename)
                loader = PyMuPDFLoader(path)
                docs.extend(loader.load())

        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1500, chunk_overlap=300)
        splits = text_splitter.split_documents(docs)
        vectorstore = Chroma.from_documents(documents=splits, embedding=embeddings, persist_directory=DB_DIR)
        print(" [RAG] 向量库构建完成。")
    else:
        print(" [RAG] 加载已有向量库。")
        vectorstore = Chroma(persist_directory=DB_DIR, embedding_function=embeddings)

    return vectorstore.as_retriever(search_kwargs={"k": 5})